import { Component } from '@angular/core';

@Component({
  standalone: true,
  template: '<p>Coming soon</p>',
})
export default class UptimePage {}
