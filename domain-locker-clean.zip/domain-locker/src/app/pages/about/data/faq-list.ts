
interface FaQ {
  question: string;
  answer: string;
}

export const faqList: FaQ[] = [];
