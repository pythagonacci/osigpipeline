import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'security-page',
  template: '<h1>Security</h1>',
})
export default class SecurityPageComponent {}
