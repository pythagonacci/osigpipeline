import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-index-page',
  template: '<h1>Value Domain Page</h1>',
})
export default class TestPageComponent {}

