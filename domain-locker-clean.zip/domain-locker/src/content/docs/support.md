---
slug: support
title: Get Help and Support
description: Need assistance with using Domain Locker? We're here to help.
---


Please note that support is only guaranteed for users on the Pro plans and above. In the future, we hope to be able to roll this out to all users.
But due to budget and time limitations, I am currently unable to offer customer support for self-hosted users, or those on the free plan. Please refer to the documentation for help instead.
