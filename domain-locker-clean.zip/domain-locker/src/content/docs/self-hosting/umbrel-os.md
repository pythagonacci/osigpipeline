---
slug: umbrel-os-app
title: Deploy to Umbrel OS
description: One-click install Domain Locker on your Umbrel OS server
index: 3
coverImage: 
---


Domain Locker is available through the Umbrel App Store.
[apps.umbrel.com/app/domain-locker](https://apps.umbrel.com/app/domain-locker)

For installation instructions, see [this guide](https://framer.umbrel.com/wip/support-234efsd/installing-apps).

Thank you [@dennysubke](https://github.com/dennysubke) for submitting it ([#2633](https://github.com/getumbrel/umbrel-apps/pull/2633))!

![screenshot](https://storage.googleapis.com/as93-screenshots/domain-locker/domain-locker-umbrel.png)
