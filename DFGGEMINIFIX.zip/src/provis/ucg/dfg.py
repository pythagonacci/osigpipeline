# src/provis/ucg/dfg.py
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Iterator, List, Optional, Tuple

from .discovery import Anomaly, AnomalyKind, AnomalySink, FileMeta, Language, Severity
from .parser_registry import CstEvent, CstEventKind, DriverInfo
from .provenance import ProvenanceV2, build_provenance_from_event


# ==============================================================================
# DFG schema (rows)
# ==============================================================================

class DfgNodeKind(str, Enum):
    PARAM = "param"
    VAR_DEF = "var_def"
    VAR_USE = "var_use"
    LITERAL = "literal"


class DfgEdgeKind(str, Enum):
    DEF_USE = "def_use"         # var_def -> var_use
    CONST_PART = "const_part"   # literal -> var_def/use (string builder parts)
    ARG_TO_PARAM = "arg_to_param"  # call arg literal/var -> callee param (intra-file seed only)


@dataclass(frozen=True)
class DfgNodeRow:
    id: str
    func_id: str
    kind: DfgNodeKind
    name: Optional[str]  # var/param name; None for literal
    version: Optional[int]  # SSA index for VAR_DEF/VAR_USE
    path: str
    lang: Language
    attrs_json: str
    prov: ProvenanceV2


@dataclass(frozen=True)
class DfgEdgeRow:
    id: str
    func_id: str
    kind: DfgEdgeKind
    src_id: str
    dst_id: str
    path: str
    lang: Language
    attrs_json: str
    prov: ProvenanceV2


# ==============================================================================
# Config
# ==============================================================================

@dataclass(frozen=True)
class DfgConfig:
    id_salt: str = "dfg-v1"
    max_defs_per_func: int = 100000   # guards for pathological files
    max_uses_per_func: int = 200000
    capture_numeric_literals: bool = True
    capture_string_literals: bool = True
    max_literal_span: int = 8192      # keep spans reasonable


# ==============================================================================
# Helpers
# ==============================================================================

def _stable_id(*parts: str) -> str:
    h = hashlib.blake2b(digest_size=20)
    for p in parts:
        h.update(b"\x1f")
        h.update(p.encode("utf-8", "ignore"))
    return h.hexdigest()


def _compact(obj: dict) -> str:
    return json.dumps(obj, separators=(",", ":"), sort_keys=True)


# ==============================================================================
# State Management Classes
# ==============================================================================

@dataclass
class _VariableState:
    """Tracks the SSA version and defining node ID of a single variable."""
    name: str
    version: int = 0
    defining_node_id: Optional[str] = None


class Scope:
    """Manages the state of all variables within a single lexical scope."""
    
    def __init__(self, scope_id: str, parent: Optional['Scope'] = None):
        self.scope_id = scope_id
        self.parent = parent
        self.variables: Dict[str, _VariableState] = {}
    
    def find_variable(self, name: str) -> Optional[_VariableState]:
        """Find a variable in this scope or parent scopes."""
        if name in self.variables:
            return self.variables[name]
        if self.parent:
            return self.parent.find_variable(name)
        return None
    
    def define_variable(self, name: str, defining_node_id: str) -> _VariableState:
        """Create a new SSA version of a variable in this scope."""
        existing = self.variables.get(name)
        if existing:
            new_version = existing.version + 1
        else:
            new_version = 0
        
        var_state = _VariableState(
            name=name,
            version=new_version,
            defining_node_id=defining_node_id
        )
        self.variables[name] = var_state
        return var_state


# ==============================================================================
# Language adapters (assignment/ident/params)
# ==============================================================================

class _Adapter:
    """Spot assignment sites, identifier tokens, params, and string/number tokens."""

    def __init__(self, lang: Language) -> None:
        self.lang = lang
        self._init_sets()

    def _init_sets(self) -> None:
        if self.lang == Language.PY:
            # statement/expr nodes
            self.function_nodes = {"FunctionDef", "AsyncFunctionDef", "Lambda"}
            self.param_list_nodes = {"Parameters"}  # libcst Parameters node; we’ll also accept PARAM tokens
            self.assign_nodes = {"Assign", "AnnAssign", "AugAssign"}
            self.identifier_tokens = {"Name", "Attribute"}  # conservative
            self.string_tokens = {"SimpleString"}
            self.number_tokens = {"Integer", "Float"}
            self.call_nodes = {"Call"}
            self.arg_name_tokens = {"Name"}  # simple heuristic
            self.param_token_types = {"Name"}  # parameter names appear as Name tokens inside parameters list
            self.assignment_operators = {"=", "+=", "-=", "*=", "/=", "%=", "**=", "//=", "|=", "&=", "^=", ">>=", "<<="}
        else:
            # JS/TS
            self.function_nodes = {"function_declaration", "function_expression", "method_definition", "arrow_function"}
            self.param_list_nodes = {"formal_parameters"}
            self.assign_nodes = {"variable_declarator", "assignment_expression"}
            self.identifier_tokens = {"identifier", "property_identifier", "shorthand_property_identifier", "private_property_identifier"}
            self.string_tokens = {"string", "string_fragment", "string_literal", "template_string"}
            self.number_tokens = {"number"}
            self.call_nodes = {"call_expression", "new_expression"}
            self.arg_name_tokens = {"identifier", "property_identifier"}
            self.param_token_types = {"identifier"}
            self.assignment_operators = {"=", "+=", "-=", "*=", "/=", "%=", "**=", "|=", "&=", "^=", ">>=", "<<="}

    def is_function(self, t: str) -> bool: return t in self.function_nodes
    def is_param_list(self, t: str) -> bool: return t in self.param_list_nodes
    def is_assign(self, t: str) -> bool: return t in self.assign_nodes
    def is_identifier_token(self, t: str) -> bool: return t in self.identifier_tokens
    def is_string_token(self, t: str) -> bool: return t in self.string_tokens
    def is_number_token(self, t: str) -> bool: return t in self.number_tokens
    def is_call(self, t: str) -> bool: return t in self.call_nodes
    def is_param_token(self, t: str) -> bool: return t in self.param_token_types
    def is_assignment_operator(self, tok: str) -> bool: return tok in self.assignment_operators


# ==============================================================================
# DFG builder
# ==============================================================================

class DfgBuilder:
    """Robust, single-pass DFG builder with stack-based assignment analysis."""

    def __init__(self, fm: FileMeta, info: Optional[DriverInfo], events: List[CstEvent], sink: AnomalySink, cfg: DfgConfig):
        self.fm = fm
        self.info = info
        self.events = events
        self.sink = sink
        self.cfg = cfg
        self.adapter = _Adapter(fm.lang)
        self.scope_stack: List[Scope] = []
        self.node_stack: List[CstEvent] = []  # Track depth in CST for expression structure
        self.defs_count = 0
        self.uses_count = 0

    def build(self) -> Iterator[Tuple[str, object]]:
        """Single-pass analysis using stack-based assignment detection."""
        if not self.events:
            return

        # Initialize root scope for the file (same as symbols builder)
        root_scope_id = _stable_id(self.cfg.id_salt, "module", self.fm.path, self.fm.blob_sha or "")
        root_scope = Scope(root_scope_id, None)
        self.scope_stack.append(root_scope)

        for ev in self.events:
            if ev.kind == CstEventKind.ENTER:
                self.node_stack.append(ev)
                
                if self.adapter.is_function(ev.type):
                    yield from self._process_function_enter(ev)
                elif self.adapter.is_assign(ev.type):
                    yield from self._process_assignment_enter(ev)
                    
            elif ev.kind == CstEventKind.TOKEN:
                yield from self._process_token(ev)
                
            elif ev.kind == CstEventKind.EXIT:
                if self.node_stack:
                    popped = self.node_stack.pop()
                    if self.adapter.is_function(popped.type):
                        if self.scope_stack:
                            self.scope_stack.pop()

    def _process_function_enter(self, ev: CstEvent) -> Iterator[Tuple[str, object]]:
        """Process function ENTER event - create scope and identify parameters."""
        if not self.scope_stack:
            return
            
        # Get function name from the event span
        func_name = self._extract_function_name(ev)
        parent_scope = self.scope_stack[-1]
        
        # Use the same scope ID generation logic as symbols builder
        parent_id = parent_scope.scope_id if parent_scope else ""
        func_id = _stable_id(self.cfg.id_salt, "scope", self.fm.path, self.fm.blob_sha or "", parent_id, "function", func_name, str(ev.byte_start))
        
        # Create new function scope
        func_scope = Scope(func_id, parent_scope)
        self.scope_stack.append(func_scope)
        
        # Find parameters within this function's event span
        params = self._find_parameters_in_function(ev)
        for param_name in params:
            param_node_id = self._node_id(DfgNodeKind.PARAM, func_id, param_name, 0, ev)
            param_row = DfgNodeRow(
                id=param_node_id, func_id=func_id, kind=DfgNodeKind.PARAM, name=param_name, version=0,
                path=self.fm.path, lang=self.fm.lang, attrs_json=_compact({}),
                prov=build_provenance_from_event(self.fm, self.info, ev),
            )
            yield ("dfg_node", param_row)
            
            # Add parameter to scope
            var_state = _VariableState(name=param_name, version=0, defining_node_id=param_node_id)
            func_scope.variables[param_name] = var_state

    def _process_assignment_enter(self, ev: CstEvent) -> Iterator[Tuple[str, object]]:
        """Process assignment ENTER event - analyze structure to find LHS/RHS."""
        if not self.scope_stack:
            return
            
        # Find assignment operator and partition children into LHS/RHS
        assignment_op_pos = self._find_assignment_operator(ev)
        if assignment_op_pos is None:
            return
            
        # Find all identifier tokens within this assignment
        lhs_identifiers, rhs_identifiers = self._partition_assignment_identifiers(ev, assignment_op_pos)
        
        current_scope = self.scope_stack[-1]
        func_id = current_scope.scope_id
        
        # Process LHS identifiers as definitions
        for name, token_ev in lhs_identifiers:
            var_state = current_scope.define_variable(name, "")
            var_state.defining_node_id = self._node_id(DfgNodeKind.VAR_DEF, func_id, name, var_state.version, token_ev)
            
            self.defs_count += 1
            def_row = DfgNodeRow(
                id=var_state.defining_node_id, func_id=func_id, kind=DfgNodeKind.VAR_DEF, name=name, version=var_state.version,
                path=self.fm.path, lang=self.fm.lang, attrs_json=_compact({}),
                prov=build_provenance_from_event(self.fm, self.info, token_ev),
            )
            yield ("dfg_node", def_row)
        
        # Process RHS identifiers as uses
        for name, token_ev in rhs_identifiers:
            var_state = current_scope.find_variable(name)
            if var_state and var_state.defining_node_id:
                self.uses_count += 1
                use_node_id = self._node_id(DfgNodeKind.VAR_USE, func_id, name, var_state.version, token_ev)
                use_row = DfgNodeRow(
                    id=use_node_id, func_id=func_id, kind=DfgNodeKind.VAR_USE, name=name, version=var_state.version,
                    path=self.fm.path, lang=self.fm.lang, attrs_json=_compact({}),
                    prov=build_provenance_from_event(self.fm, self.info, token_ev),
                )
                yield ("dfg_node", use_row)
                
                # Create DEF_USE edge
                edge_id = self._edge_id(DfgEdgeKind.DEF_USE, func_id, var_state.defining_node_id, use_node_id, token_ev)
                edge_row = DfgEdgeRow(
                    id=edge_id, func_id=func_id, kind=DfgEdgeKind.DEF_USE, src_id=var_state.defining_node_id, dst_id=use_node_id,
                    path=self.fm.path, lang=self.fm.lang, attrs_json=_compact({"name": name, "version": var_state.version}),
                    prov=build_provenance_from_event(self.fm, self.info, token_ev),
                )
                yield ("dfg_edge", edge_row)
        
        # Check for simple alias pattern: exactly one LHS and one RHS identifier
        if len(lhs_identifiers) == 1 and len(rhs_identifiers) == 1:
            lhs_name, _ = lhs_identifiers[0]
            rhs_name, _ = rhs_identifiers[0]
            
            # Emit alias hint
            alias_hint = {
                "lhs_name": lhs_name,
                "rhs_name": rhs_name,
                "scope_id": current_scope.scope_id,
                "byte_start": ev.byte_start,
                "byte_end": ev.byte_end,
            }
            yield ("alias_hint", alias_hint)

    def _process_token(self, ev: CstEvent) -> Iterator[Tuple[str, object]]:
        """Process a token event for variable usage (outside assignments)."""
        if not self.adapter.is_identifier_token(ev.type):
            return
            
        # Only process tokens that are NOT inside assignment nodes
        if self._is_inside_assignment():
            return
            
        if not self.scope_stack:
            return
            
        name = self._safe_token_name(ev, self.fm)
        if not name:
            return
            
        current_scope = self.scope_stack[-1]
        func_id = current_scope.scope_id
        
        # Find the variable in scope hierarchy
        var_state = current_scope.find_variable(name)
        if var_state and var_state.defining_node_id:
            # This is a use of an existing variable
            self.uses_count += 1
            use_node_id = self._node_id(DfgNodeKind.VAR_USE, func_id, name, var_state.version, ev)
            use_row = DfgNodeRow(
                id=use_node_id, func_id=func_id, kind=DfgNodeKind.VAR_USE, name=name, version=var_state.version,
                path=self.fm.path, lang=self.fm.lang, attrs_json=_compact({}), 
                prov=build_provenance_from_event(self.fm, self.info, ev),
            )
            yield ("dfg_node", use_row)
            
            # Create DEF_USE edge
            edge_id = self._edge_id(DfgEdgeKind.DEF_USE, func_id, var_state.defining_node_id, use_node_id, ev)
            edge_row = DfgEdgeRow(
                id=edge_id, func_id=func_id, kind=DfgEdgeKind.DEF_USE, src_id=var_state.defining_node_id, dst_id=use_node_id,
                path=self.fm.path, lang=self.fm.lang, attrs_json=_compact({"name": name, "version": var_state.version}),
                prov=build_provenance_from_event(self.fm, self.info, ev),
            )
            yield ("dfg_edge", edge_row)

    def _extract_function_name(self, ev: CstEvent) -> str:
        """Extract function name from function ENTER event."""
        # Read the function span to find the name
        try:
            with open(self.fm.real_path, "rb") as f:
                f.seek(ev.byte_start)
                span_bytes = f.read(min(512, ev.byte_end - ev.byte_start))
            text = span_bytes.decode(self.fm.encoding or "utf-8", errors="ignore")
            
            # Look for function definition patterns
            if self.fm.lang == Language.PY:
                # Python: def function_name(... or lambda param: ...
                if "def " in text:
                    parts = text.split("def ", 1)[1].split("(")[0].strip()
                    return parts if parts else "<function>"
                elif "lambda" in text:
                    return "<lambda>"
            else:
                # JS/TS: function name(... or name = function(... or name = (...)
                for pattern in ["function ", "= function", "= ("]:
                    if pattern in text:
                        if pattern == "function ":
                            parts = text.split("function ", 1)[1].split("(")[0].strip()
                            return parts if parts else "<function>"
                        elif "= function" in text:
                            parts = text.split("=")[0].strip().split()[-1]
                            return parts if parts else "<function>"
                        elif "= (" in text:
                            parts = text.split("=")[0].strip().split()[-1]
                            return parts if parts else "<function>"
        except Exception:
            pass
        return "<function>"

    def _find_parameters_in_function(self, ev: CstEvent) -> List[str]:
        """Find parameter names within a function's event span."""
        params = []
        try:
            with open(self.fm.real_path, "rb") as f:
                f.seek(ev.byte_start)
                span_bytes = f.read(min(1024, ev.byte_end - ev.byte_start))
            text = span_bytes.decode(self.fm.encoding or "utf-8", errors="ignore")
            
            # Look for parameter list
            if "(" in text and ")" in text:
                start = text.find("(")
                end = text.find(")", start)
                param_text = text[start+1:end]
                
                # Simple parameter extraction
                for param in param_text.split(","):
                    param = param.strip()
                    # Remove type annotations, defaults, etc.
                    for sep in [":", "=", " "]:
                        if sep in param:
                            param = param.split(sep)[0].strip()
                    if param and param.isidentifier():
                        params.append(param)
        except Exception:
            pass
        return params

    def _find_assignment_operator(self, ev: CstEvent) -> Optional[int]:
        """Find the position of the assignment operator within the assignment node."""
        try:
            with open(self.fm.real_path, "rb") as f:
                f.seek(ev.byte_start)
                span_bytes = f.read(min(512, ev.byte_end - ev.byte_start))
            text = span_bytes.decode(self.fm.encoding or "utf-8", errors="ignore")
            
            # Look for assignment operators
            for op in ["=", "+=", "-=", "*=", "/=", "%=", "**=", "//=", "|=", "&=", "^=", ">>=", "<<="]:
                if op in text:
                    return text.find(op)
        except Exception:
            pass
        return None

    def _partition_assignment_identifiers(self, ev: CstEvent, op_pos: int) -> Tuple[List[Tuple[str, CstEvent]], List[Tuple[str, CstEvent]]]:
        """Partition identifier tokens into LHS and RHS based on operator position."""
        lhs_identifiers = []
        rhs_identifiers = []
        
        # Find all identifier tokens within this assignment
        assignment_tokens = []
        for token_ev in self.events:
            if (token_ev.kind == CstEventKind.TOKEN and 
                self.adapter.is_identifier_token(token_ev.type) and
                ev.byte_start <= token_ev.byte_start < ev.byte_end):
                name = self._safe_token_name(token_ev, self.fm)
                if name:
                    assignment_tokens.append((token_ev, name))
        
        # Partition based on operator position
        for token_ev, name in assignment_tokens:
            # Get relative position within assignment
            rel_pos = token_ev.byte_start - ev.byte_start
            if rel_pos < op_pos:
                lhs_identifiers.append((name, token_ev))
            elif rel_pos > op_pos:
                rhs_identifiers.append((name, token_ev))
        
        return lhs_identifiers, rhs_identifiers

    def _is_inside_assignment(self) -> bool:
        """Check if we're currently inside an assignment node."""
        for node in reversed(self.node_stack):
            if self.adapter.is_assign(node.type):
                return True
        return False

    def _node_id(self, kind: DfgNodeKind, func_id: str, name: Optional[str], version: Optional[int], ev: CstEvent) -> str:
        """Generate stable node ID."""
        vpart = "" if version is None else str(version)
        nmpart = "" if name is None else name
        return _stable_id(self.cfg.id_salt, "node", self.fm.path, self.fm.blob_sha, func_id, kind.value, nmpart, vpart, str(ev.byte_start))

    def _edge_id(self, kind: DfgEdgeKind, func_id: str, src: str, dst: str, ev: CstEvent) -> str:
        """Generate stable edge ID."""
        return _stable_id(self.cfg.id_salt, "edge", self.fm.path, self.fm.blob_sha, func_id, kind.value, src, dst, str(ev.byte_start))

    def _safe_token_name(self, ev: CstEvent, fm: FileMeta) -> Optional[str]:
        """Memory-lean, conservative identifier extraction (<=1KB slice)."""
        try:
            if ev.byte_end <= ev.byte_start:
                return None
            size = ev.byte_end - ev.byte_start
            if size > 1024:
                return None
            with open(fm.real_path, "rb") as f:
                f.seek(ev.byte_start)
                token = f.read(size)
            text = token.decode(fm.encoding or "utf-8", errors="replace").strip()
            if not text or len(text) > 256:
                return None
            ch0 = text[0]
            if not (ch0.isalpha() or ch0 == "_"):
                return None
            for ch in text[1:]:
                if not (ch.isalnum() or ch in "._$"):
                    return None
            # avoid pure numbers
            if text.replace("_", "").isdigit():
                return None
            return text
        except Exception:
            return None

    def _safe_token_text(self, ev: CstEvent, fm: FileMeta) -> Optional[str]:
        """Extract token text for any token type."""
        try:
            if ev.byte_end <= ev.byte_start:
                return None
            size = ev.byte_end - ev.byte_start
            if size > 1024:
                return None
            with open(fm.real_path, "rb") as f:
                f.seek(ev.byte_start)
                token = f.read(size)
            text = token.decode(fm.encoding or "utf-8", errors="replace").strip()
            if not text or len(text) > 256:
                return None
            return text
        except Exception:
            return None


# ==============================================================================
# Public convenience
# ==============================================================================

def build_dfg(fm: FileMeta, info: Optional[DriverInfo], events: List[CstEvent], sink: AnomalySink, cfg: Optional[DfgConfig] = None) -> Iterator[Tuple[str, object]]:
    builder = DfgBuilder(fm, info, events, sink, cfg or DfgConfig())
    yield from builder.build()
